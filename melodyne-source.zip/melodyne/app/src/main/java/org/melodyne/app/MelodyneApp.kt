package org.melodyne.app

import android.app.Application
import org.melodyne.app.di.ServiceLocator

class MelodyneApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ServiceLocator.init(this)
    }
}
