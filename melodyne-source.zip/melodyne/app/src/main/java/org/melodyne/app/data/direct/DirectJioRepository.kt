package org.melodyne.app.data.direct

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import org.melodyne.app.data.repo.ApiUnavailable
import org.melodyne.app.domain.LrcParser
import org.melodyne.app.domain.Lyrics
import org.melodyne.app.domain.MusicRepository
import org.melodyne.app.domain.Playlist
import org.melodyne.app.domain.PlaylistInfo
import org.melodyne.app.domain.Song
import retrofit2.HttpException
import java.io.IOException

/**
 * Talks to JioSaavn's own web API, the same one the web player and every unofficial wrapper
 * (sumitkolhe/jiosaavn-api included) sits on. No third-party server in the middle that can run
 * out of quota (402) or disappear. Streams: decrypt `encrypted_media_url`, then ask for 320 kbps.
 */
class DirectJioRepository(private val api: JioApi, private val json: Json) : MusicRepository {

    private suspend fun get(vararg extra: Pair<String, String>): String {
        val params = mapOf("_format" to "json", "_marker" to "0", "api_version" to "4", "ctx" to "web6dot0") + extra
        try {
            return withContext(Dispatchers.IO) { api.call(params).string() }
        } catch (e: HttpException) {
            throw ApiUnavailable(e, listOf("jiosaavn.com: HTTP ${e.code()}"))
        } catch (e: IOException) {
            throw ApiUnavailable(e, listOf("jiosaavn.com: ${e.javaClass.simpleName} ${e.message.orEmpty().take(60)}"))
        }
    }

    private suspend fun <T> parse(text: String, ser: kotlinx.serialization.KSerializer<T>): T = try {
        json.decodeFromString(ser, text)
    } catch (e: SerializationException) {
        throw ApiUnavailable(e, listOf("jiosaavn.com: unexpected reply \"${text.take(50).replace('\n', ' ')}\""))
    } catch (e: IllegalArgumentException) {
        throw ApiUnavailable(e, listOf("jiosaavn.com: unexpected reply \"${text.take(50).replace('\n', ' ')}\""))
    }

    override suspend fun search(query: String): List<Song> {
        val r = parse(get("__call" to "search.getResults", "q" to query, "p" to "1", "n" to "25"), JSearch.serializer())
        return r.results.mapNotNull { it.toSong() }
    }

    override suspend fun searchPlaylists(query: String): List<PlaylistInfo> {
        val r = parse(get("__call" to "search.getPlaylistResults", "q" to query, "p" to "1", "n" to "12"), JPlaylistSearch.serializer())
        return r.results.map { PlaylistInfo(it.id, it.title.clean(), it.image.big()) }
    }

    override suspend fun playlist(id: String): Playlist {
        val r = parse(get("__call" to "playlist.getDetails", "listid" to id, "p" to "1", "n" to "50"), JPlaylist.serializer())
        return Playlist(PlaylistInfo(r.id, r.title.clean(), r.image.big()), r.list.mapNotNull { it.toSong() })
    }

    override suspend fun lyrics(songId: String): Lyrics? = try {
        val r = parse(get("__call" to "lyrics.getLyrics", "lyrics_id" to songId), JLyrics.serializer())
        r.lyrics?.takeIf { it.isNotBlank() }?.let { LrcParser.parse(it) }
    } catch (e: ApiUnavailable) {
        null
    }
}

private fun String.clean() = replace("&quot;", "\"").replace("&amp;", "&").replace("&#039;", "'")
private fun String.big() = replace("150x150", "500x500").replace("50x50", "500x500").takeIf { it.isNotBlank() }

private fun JSong.toSong(): Song? {
    val m = more ?: return null
    val base = JioCrypto.decrypt(m.encryptedUrl ?: return null) ?: return null
    // 320 kbps exists only when the song is flagged for it; otherwise take the next best.
    val kbps = if (m.kbps320 == "true") 320 else 160
    val artists = m.artistMap?.primary?.takeIf { it.isNotEmpty() } ?: m.artistMap?.artists.orEmpty()
    return Song(
        id = id,
        title = title.clean(),
        artist = artists.joinToString(", ") { it.name.clean() }.ifBlank { subtitle.substringBefore(" - ").clean() },
        album = m.album.clean(),
        durationSec = m.duration?.toIntOrNull() ?: 0,
        artUrl = image.big(),
        thumbUrl = image.takeIf { it.isNotBlank() },
        streamUrl = JioCrypto.withBitrate(base, kbps),
        streamKbps = kbps,
        hasLyrics = m.hasLyrics == "true",
    )
}
