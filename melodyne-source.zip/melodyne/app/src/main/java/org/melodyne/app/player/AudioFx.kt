package org.melodyne.app.player

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import org.melodyne.app.audio.EqController
import org.melodyne.app.audio.EqPresets
import org.melodyne.app.audio.EqState
import kotlin.math.roundToInt

/**
 * Real DSP, not cosmetics: attaches Android's system Equalizer, BassBoost, Virtualizer and
 * LoudnessEnhancer to ExoPlayer's audio session and drives them from the selected preset.
 * Each preset curve is resampled onto whatever band layout the device exposes.
 */
@UnstableApi
class AudioFx(
    private val player: ExoPlayer,
    private val eq: EqController,
    private val scope: CoroutineScope,
) {
    private var session = C.AUDIO_SESSION_ID_UNSET
    private var equalizer: Equalizer? = null
    private var bass: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudness: LoudnessEnhancer? = null

    fun attach() {
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) { build(audioSessionId) }
        })
        build(player.audioSessionId)
        scope.launch { eq.state.collect { apply(it) } }
    }

    fun release() { releaseEffects(); session = C.AUDIO_SESSION_ID_UNSET }

    private fun build(id: Int) {
        if (id == session) return
        releaseEffects()
        session = id
        if (id == C.AUDIO_SESSION_ID_UNSET) { eq.reportStatus("Waiting for an audio session"); return }
        equalizer = runCatching { Equalizer(0, id) }.getOrNull()
        bass = runCatching { BassBoost(0, id) }.getOrNull()
        virtualizer = runCatching { Virtualizer(0, id) }.getOrNull()
        loudness = runCatching { LoudnessEnhancer(id) }.getOrNull()
        apply(eq.state.value)
        eq.reportStatus(describe())
    }

    private fun describe(): String {
        val e = equalizer ?: return "This device exposes no system equalizer, so presets can't be applied"
        val extras = listOfNotNull(
            "bass".takeIf { bass != null }, "surround".takeIf { virtualizer != null }, "loudness".takeIf { loudness != null },
        )
        return "Active · ${e.numberOfBands} bands" + if (extras.isEmpty()) "" else " + " + extras.joinToString(", ")
    }

    private fun apply(s: EqState) {
        val p = EqPresets.byId(s.presetId)
        val k = s.intensity
        runCatching {
            equalizer?.let { e ->
                val range = e.bandLevelRange
                for (b in 0 until e.numberOfBands.toInt()) {
                    val hz = e.getCenterFreq(b.toShort()) / 1000f
                    val mb = (p.gainAt(hz) * k * 100f).roundToInt().coerceIn(range[0].toInt(), range[1].toInt())
                    e.setBandLevel(b.toShort(), mb.toShort())
                }
                e.setEnabled(s.enabled)
            }
        }
        runCatching {
            bass?.let { b ->
                val str = (p.bass * k).roundToInt()
                if (b.strengthSupported) b.setStrength(str.coerceIn(0, 1000).toShort())
                b.setEnabled(s.enabled && str > 0)
            }
        }
        runCatching {
            virtualizer?.let { v ->
                val str = (p.surround * k).roundToInt()
                if (v.strengthSupported) v.setStrength(str.coerceIn(0, 1000).toShort())
                v.setEnabled(s.enabled && str > 0)
            }
        }
        runCatching {
            loudness?.let { l ->
                val mb = (p.loudnessMb * k).roundToInt()
                l.setTargetGain(mb)
                l.setEnabled(s.enabled && mb > 0)
            }
        }
    }

    private fun releaseEffects() {
        equalizer?.let { runCatching { it.release() } }; equalizer = null
        bass?.let { runCatching { it.release() } }; bass = null
        virtualizer?.let { runCatching { it.release() } }; virtualizer = null
        loudness?.let { runCatching { it.release() } }; loudness = null
    }
}
