package org.melodyne.app.data.remote

import retrofit2.http.GET
import retrofit2.http.Query
import retrofit2.http.Url

/**
 * Shape follows sumitkolhe/jiosaavn-api. The host is passed per call (@Url) so the repository
 * can fail over between hosts when one answers 402/429/5xx.
 */
interface SaavnApi {
    @GET suspend fun searchSongs(
        @Url url: String, @Query("query") query: String,
        @Query("page") page: Int, @Query("limit") limit: Int,
    ): Envelope<SearchData>

    @GET suspend fun searchPlaylists(
        @Url url: String, @Query("query") query: String,
        @Query("page") page: Int, @Query("limit") limit: Int,
    ): Envelope<PlaylistSearchData>

    @GET suspend fun playlist(
        @Url url: String, @Query("id") id: String,
        @Query("page") page: Int, @Query("limit") limit: Int,
    ): Envelope<PlaylistDto>

    /** UNVERIFIED path: adjust in SaavnRepository.lyrics() if your host exposes lyrics elsewhere. */
    @GET suspend fun lyrics(@Url url: String): Envelope<LyricsDto>
}
