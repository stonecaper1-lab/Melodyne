package org.melodyne.app.audio

import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class EqState(val enabled: Boolean = true, val presetId: String = "flat", val intensity: Float = 1f)

/** Shared by the Sound screen (writes) and the playback service (applies it to the audio session). */
class EqController(private val prefs: SharedPreferences) {
    private val _state = MutableStateFlow(
        EqState(
            enabled = prefs.getBoolean("eq_on", true),
            presetId = prefs.getString("eq_preset", "flat") ?: "flat",
            intensity = prefs.getFloat("eq_intensity", 1f).coerceIn(0f, 1f),
        )
    )
    val state: StateFlow<EqState> = _state.asStateFlow()

    private val _status = MutableStateFlow("Starts with your next song")
    val status: StateFlow<String> = _status.asStateFlow()

    fun setPreset(id: String) {
        prefs.edit().putString("eq_preset", id).apply()
        _state.update { it.copy(presetId = id) }
    }

    fun setIntensity(v: Float) {
        val f = v.coerceIn(0f, 1f)
        prefs.edit().putFloat("eq_intensity", f).apply()
        _state.update { it.copy(intensity = f) }
    }

    fun setEnabled(on: Boolean) {
        prefs.edit().putBoolean("eq_on", on).apply()
        _state.update { it.copy(enabled = on) }
    }

    fun reportStatus(s: String) { _status.value = s }
}
