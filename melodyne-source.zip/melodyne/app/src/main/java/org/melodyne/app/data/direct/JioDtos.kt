package org.melodyne.app.data.direct

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import okhttp3.ResponseBody
import retrofit2.http.GET
import retrofit2.http.QueryMap

/** Raw shapes of www.jiosaavn.com/api.php (api_version=4, ctx=web6dot0). Everything is optional on purpose. */
@Serializable data class JArtist(val id: String = "", val name: String = "")
@Serializable data class JArtistMap(
    @SerialName("primary_artists") val primary: List<JArtist> = emptyList(),
    val artists: List<JArtist> = emptyList(),
)

@Serializable
data class JMore(
    val album: String = "",
    val duration: String? = null,
    @SerialName("has_lyrics") val hasLyrics: String? = null,
    @SerialName("320kbps") val kbps320: String? = null,
    @SerialName("encrypted_media_url") val encryptedUrl: String? = null,
    val artistMap: JArtistMap? = null,
)

@Serializable
data class JSong(
    val id: String = "",
    val title: String = "",
    val subtitle: String = "",
    val image: String = "",
    @SerialName("more_info") val more: JMore? = null,
)

@Serializable data class JSearch(val results: List<JSong> = emptyList())
@Serializable data class JPlaylist(val id: String = "", val title: String = "", val image: String = "", val list: List<JSong> = emptyList())
@Serializable data class JPlaylistSearch(val results: List<JPlaylist> = emptyList())
@Serializable data class JLyrics(val lyrics: String? = null)

interface JioApi {
    @GET("api.php")
    suspend fun call(@QueryMap params: Map<String, String>): ResponseBody
}
