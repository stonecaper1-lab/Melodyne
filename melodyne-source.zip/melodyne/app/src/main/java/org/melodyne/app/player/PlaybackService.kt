package org.melodyne.app.player

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import org.melodyne.app.MainActivity
import org.melodyne.app.di.ServiceLocator
import org.melodyne.app.widget.WidgetSnapshot
import org.melodyne.app.widget.WidgetUpdater
import java.io.File

/**
 * Owns ExoPlayer + MediaSession. Media3 supplies the foreground notification, lock-screen and Bluetooth controls.
 * Stream quality is broadcast through session extras; every audio frame passes the BitrateMeter on its way in;
 * the EQ and normaliser sit inside the audio sink; a helper player carries the outgoing song during a crossfade.
 */
@UnstableApi
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var cache: SimpleCache? = null
    private var engine: CrossfadeEngine? = null
    private var widgetJob: Job? = null
    private var widgetTick: Job? = null
    private var lastQuality = ""
    private val eqProcessors = ArrayList<EqProcessor>()
    private val loudnessProcessor = LoudnessProcessor(ServiceLocator.normalizer)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var dataSources: CacheDataSource.Factory
    private val musicAttrs = AudioAttributes.Builder().setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).setUsage(C.USAGE_MEDIA).build()

    private fun renderers(eq: EqProcessor, loudness: LoudnessProcessor?, meter: MeterProcessor? = null): DefaultRenderersFactory =
        object : DefaultRenderersFactory(this@PlaybackService) {
            override fun buildAudioSink(context: Context, enableFloatOutput: Boolean, enableAudioTrackPlaybackParams: Boolean): AudioSink =
                DefaultAudioSink.Builder(context)
                    .setEnableFloatOutput(enableFloatOutput)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .setAudioProcessors(listOfNotNull<AudioProcessor>(loudness, eq, meter).toTypedArray())
                    .build()
        }

    private fun applyEq(p: EqProcessor) {
        val e = ServiceLocator.eq.state.value
        val pb = ServiceLocator.playback.state.value
        val plain = pb.audiophile || pb.frugal
        p.update(e.gains, e.enabled && !plain, if (plain) 1f else 1f + pb.width, if (plain) 0f else pb.balance)
    }

    private fun newTailPlayer(): ExoPlayer {
        val eq = EqProcessor().also { eqProcessors += it; applyEq(it) }
        return ExoPlayer.Builder(this, renderers(eq, null))
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSources))
            .setAudioAttributes(musicAttrs, /* handleAudioFocus = */ false)
            .setHandleAudioBecomingNoisy(true)
            .build()
    }

    override fun onCreate() {
        super.onCreate()
        val c = SimpleCache(
            File(cacheDir, "audio"), LeastRecentlyUsedCacheEvictor(64L * 1024 * 1024), StandaloneDatabaseProvider(this),
        )
        cache = c
        dataSources = CacheDataSource.Factory()
            .setCache(c)
            .setUpstreamDataSourceFactory(OkHttpDataSource.Factory(ServiceLocator.http))
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)

        val eqMain = EqProcessor().also { eqProcessors += it }
        val extractors = MeteringExtractorsFactory(DefaultExtractorsFactory(), ServiceLocator.bitrate)
        // Frugal mode buffers 15 to 30 seconds ahead instead of 50, so skipping wastes less data (applies from the next start).
        val frugalNow = ServiceLocator.playback.state.value.frugal
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(if (frugalNow) 15_000 else 50_000, if (frugalNow) 30_000 else 50_000, 1_500, 3_000)
            .build()
        val player = ExoPlayer.Builder(this, renderers(eqMain, loudnessProcessor, MeterProcessor()))
            .setLoadControl(loadControl)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSources, extractors))
            .setAudioAttributes(musicAttrs, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()

        // Tapping the notification or lock-screen card opens Vina straight on the Now Playing screen.
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(MainActivity.EXTRA_OPEN_PLAYER, true),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val s = MediaSession.Builder(this, player).setSessionActivity(openApp).build()
        session = s
        QualityMonitor(player) { q -> s.setSessionExtras(q.toBundle()); lastQuality = q.label(); scheduleWidget(player) }.attach()
        Scrobbling(player, scope, ServiceLocator.lastFm).attach()
        // Keep the Now Playing home-screen widget in step with the player.
        player.addListener(object : androidx.media3.common.Player.Listener {
            override fun onEvents(p: androidx.media3.common.Player, events: androidx.media3.common.Player.Events) {
                if (events.containsAny(
                        androidx.media3.common.Player.EVENT_MEDIA_ITEM_TRANSITION, androidx.media3.common.Player.EVENT_IS_PLAYING_CHANGED,
                        androidx.media3.common.Player.EVENT_MEDIA_METADATA_CHANGED, androidx.media3.common.Player.EVENT_PLAYBACK_STATE_CHANGED,
                    )
                ) scheduleWidget(p)
            }
        })
        engine = CrossfadeEngine(player, { newTailPlayer() }, ServiceLocator.playback, ServiceLocator.normalizer, scope).also { it.attach() }

        SleepEngine(player, ServiceLocator.sleep, scope) { engine?.isFading == true }.attach()

        // Audiophile Mode bypasses every processor; otherwise the EQ and normalisation follow the user's settings.
        scope.launch {
            combine(ServiceLocator.eq.state, ServiceLocator.playback.state) { e, p -> e to p }.collect { (e, p) ->
                val plain = p.audiophile || p.frugal                        // Audiophile and Frugal both leave the audio untouched
                val w = if (plain) 1f else 1f + p.width
                val bal = if (plain) 0f else p.balance
                eqProcessors.forEach { it.update(e.gains, e.enabled && !plain, w, bal) }
                ServiceLocator.normalizer.enabled = p.normalizeEffective
                ServiceLocator.normalizer.maxBoostDb = if (p.normGentle) 0.0 else org.melodyne.app.audio.Loudness.MAX_GAIN_DB
                OutputInspector.applyBitPerfect(this@PlaybackService, p.audiophile)
            }
        }
        // The song id lets the normaliser remember a measured gain per song.
        player.addListener(object : androidx.media3.common.Player.Listener {
            override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
                ServiceLocator.normalizer.currentKey = mediaItem?.mediaId
            }
        })
        ServiceLocator.normalizer.currentKey = player.currentMediaItem?.mediaId
    }

    private suspend fun pushWidget(p: androidx.media3.common.Player) {
        val md = p.mediaMetadata
        WidgetUpdater.update(
            this,
            WidgetSnapshot(
                md.title?.toString().orEmpty(), md.artist?.toString().orEmpty(), lastQuality, p.isPlaying, md.artworkUri?.toString(),
                p.currentPosition, p.duration.takeIf { it > 0 } ?: 0L,
            ),
        )
    }

    /** Updates the widget soon after any change, and every five seconds while playing so its progress bar keeps moving. */
    private fun scheduleWidget(p: androidx.media3.common.Player) {
        widgetJob?.cancel()
        widgetJob = scope.launch { delay(300); pushWidget(p) }
        widgetTick?.cancel()
        if (p.isPlaying) widgetTick = scope.launch { while (isActive) { delay(if (ServiceLocator.playback.state.value.frugal) 20_000 else 5_000); pushWidget(p) } }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        engine?.release()
        engine = null
        session?.run { player.release(); release() }
        session = null
        cache?.release()
        cache = null
        org.melodyne.app.data.local.CacheCleaner.clearIfEnabled(applicationContext)     // the audio cache is released now, so it is safe to delete
        scope.cancel()
        super.onDestroy()
    }
}
