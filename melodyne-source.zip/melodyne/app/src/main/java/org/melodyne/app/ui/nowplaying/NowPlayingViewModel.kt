package org.melodyne.app.ui.nowplaying

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.melodyne.app.di.ServiceLocator
import org.melodyne.app.domain.Lyrics
import org.melodyne.app.domain.MusicRepository

class NowPlayingViewModel(private val repo: MusicRepository) : ViewModel() {
    private val _lyrics = MutableStateFlow<Lyrics?>(null)
    val lyrics = _lyrics.asStateFlow()
    private var loadedFor: String? = null

    /** Timed (LRC) lyrics when the API returns them, otherwise plain text; null when none. */
    fun load(songId: String?, hasLyrics: Boolean) {
        if (songId == loadedFor) return
        loadedFor = songId
        _lyrics.value = null
        if (songId == null || !hasLyrics) return
        viewModelScope.launch { _lyrics.value = runCatching { repo.lyrics(songId) }.getOrNull() }
    }

    companion object {
        val Factory = viewModelFactory { initializer { NowPlayingViewModel(ServiceLocator.repo) } }
    }
}
