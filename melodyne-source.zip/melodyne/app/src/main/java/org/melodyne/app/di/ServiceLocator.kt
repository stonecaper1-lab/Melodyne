package org.melodyne.app.di

import android.app.Application
import android.content.Context
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import org.melodyne.app.BuildConfig
import org.melodyne.app.data.lastfm.LastFmApi
import org.melodyne.app.data.lastfm.LastFmClient
import org.melodyne.app.data.lastfm.SessionStore
import org.melodyne.app.data.local.PlaylistStore
import org.melodyne.app.data.local.RecentStore
import org.melodyne.app.ai.AiClient
import org.melodyne.app.ai.AiConfigStore
import org.melodyne.app.audio.EqController
import org.melodyne.app.data.direct.DirectJioRepository
import org.melodyne.app.data.direct.JioApi
import org.melodyne.app.data.remote.SaavnApi
import org.melodyne.app.data.repo.ChainRepository
import org.melodyne.app.data.repo.HostStore
import org.melodyne.app.data.repo.SaavnRepository
import org.melodyne.app.domain.MusicRepository
import org.melodyne.app.player.PlayerConnection
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import java.util.concurrent.TimeUnit

/** Hand-rolled DI: no Hilt/Dagger/KSP, which keeps both build time and APK size down. */
private const val BROWSER_UA =
    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

object ServiceLocator {
    lateinit var app: Application
        private set

    fun init(application: Application) { app = application }

    val json = Json { ignoreUnknownKeys = true; isLenient = true; coerceInputValues = true }
    val prefs by lazy { app.getSharedPreferences("melodyne", Context.MODE_PRIVATE) }

    val http: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                chain.proceed(chain.request().newBuilder().header("User-Agent", BROWSER_UA).build())
            }
            .build()
    }

    private fun retrofit(base: String) = Retrofit.Builder()
        .baseUrl(base).client(http)
        .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
        .build()

    val hosts by lazy { HostStore(prefs) }
    val repo: MusicRepository by lazy {
        // baseUrl is a placeholder: every call passes a full @Url chosen by HostStore.
        val hosted = SaavnRepository(retrofit("https://localhost/").create(SaavnApi::class.java), hosts)
        val direct = DirectJioRepository(retrofit("https://www.jiosaavn.com/").create(JioApi::class.java), json)
        // A host the user configured wins; otherwise JioSaavn directly, then the public hosted API.
        ChainRepository { if (hosts.custom() != null) listOf(hosted, direct) else listOf(direct, hosted) }
    }
    val lastFm by lazy {
        LastFmClient(
            retrofit("https://ws.audioscrobbler.com/").create(LastFmApi::class.java),
            SessionStore(prefs), BuildConfig.LASTFM_API_KEY, BuildConfig.LASTFM_API_SECRET,
        )
    }
    val recents by lazy { RecentStore(prefs, json) }
    val playlists by lazy { PlaylistStore(prefs, json) }
    val eq by lazy { EqController(prefs) }
    val aiConfig by lazy { AiConfigStore(prefs) }
    val ai by lazy { AiClient(http, json) }
    val player by lazy { PlayerConnection(app) }
}
