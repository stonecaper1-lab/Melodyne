package org.melodyne.app.ui.sound

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.melodyne.app.audio.EqPreset
import org.melodyne.app.audio.EqPresets
import org.melodyne.app.di.ServiceLocator
import org.melodyne.app.ui.AccentSlider
import org.melodyne.app.ui.Amoled
import org.melodyne.app.ui.Chip
import org.melodyne.app.ui.LocalAccent
import org.melodyne.app.ui.Panel
import org.melodyne.app.ui.Txt
import kotlin.math.roundToInt

@Composable
fun SoundScreen() {
    val eq = ServiceLocator.eq
    val st by eq.state.collectAsState()
    val status by eq.status.collectAsState()
    val current = EqPresets.byId(st.presetId)
    val k = st.intensity
    val extras = listOfNotNull(
        "Bass boost ${(current.bass * k / 10).roundToInt()}%".takeIf { current.bass > 0 },
        "Spatial ${(current.surround * k / 10).roundToInt()}%".takeIf { current.surround > 0 },
        "Loudness +${"%.1f".format(current.loudnessMb * k / 100f)} dB".takeIf { current.loudnessMb > 0 },
    )

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Txt("Sound", size = 28.sp, weight = FontWeight.ExtraBold)
                    Txt(status, size = 12.sp, color = Amoled.Muted, maxLines = 2)
                }
                Chip(if (st.enabled) "On" else "Off", st.enabled) { eq.setEnabled(!st.enabled) }
            }
        }
        item {
            Panel(modifier = Modifier.padding(horizontal = 20.dp)) {
                Row(Modifier.fillMaxWidth()) {
                    Txt(current.name, Modifier.weight(1f), size = 16.sp, weight = FontWeight.Bold)
                    Txt("${(k * 100).roundToInt()}%", color = Amoled.Muted)
                }
                AccentSlider(k, eq::setIntensity)
                Txt(
                    if (extras.isEmpty()) "Intensity scales the whole preset. This one is a pure EQ curve." else "Also applies: " + extras.joinToString(" · "),
                    size = 12.sp, color = Amoled.Muted, maxLines = 3,
                )
            }
        }
        items(EqPresets.all.chunked(2)) { pair ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEach { p -> PresetCard(p, p.id == st.presetId, Modifier.weight(1f)) { eq.setPreset(p.id) } }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        item {
            Txt(
                "Presets drive your phone's system equalizer, bass, spatial and loudness effects on the live audio stream. " +
                    "Strength varies by device, and some phones' own sound enhancers (Dolby, etc.) can override them.",
                Modifier.padding(horizontal = 20.dp), size = 12.sp, color = Amoled.Muted, maxLines = 5,
            )
        }
    }
}

@Composable
private fun PresetCard(p: EqPreset, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val accent = LocalAccent.current
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier.height(172.dp).clip(shape).background(Amoled.Surface)
            .border(if (selected) 2.dp else 1.dp, if (selected) accent else Amoled.SurfaceHi, shape)
            .clickable(onClick = onClick).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        CurveThumb(p, if (selected) accent else Amoled.Muted, Modifier.fillMaxWidth().height(44.dp))
        Txt(p.name, size = 15.sp, weight = FontWeight.Bold, color = if (selected) accent else Amoled.OnBg)
        Txt(p.blurb, size = 11.sp, color = Amoled.Muted, maxLines = 5, lineHeight = 15.sp)
    }
}

/** The preset's EQ curve, ±7 dB full scale, drawn across the five anchor frequencies. */
@Composable
private fun CurveThumb(p: EqPreset, color: Color, modifier: Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val mid = h / 2
        drawLine(Color(0xFF2A2A2A), Offset(0f, mid), Offset(w, mid), strokeWidth = 1.dp.toPx())
        val path = Path()
        p.gains.forEachIndexed { i, g ->
            val x = w * i / (p.gains.size - 1)
            val y = mid - (g / 7f) * mid
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, color, style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
