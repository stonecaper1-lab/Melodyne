package org.melodyne.app.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.melodyne.app.data.lastfm.LastFmClient
import org.melodyne.app.data.repo.HostStore
import org.melodyne.app.di.ServiceLocator

data class SettingsUi(
    val lfConfigured: Boolean,
    val lfUser: String?,
    val busy: Boolean = false,
    val message: String? = null,
    val host: String = "",
)

class SettingsViewModel(private val lastFm: LastFmClient, private val hosts: HostStore) : ViewModel() {
    private val _ui = MutableStateFlow(SettingsUi(lastFm.configured, lastFm.loggedInUser, host = hosts.custom().orEmpty()))
    val ui = _ui.asStateFlow()

    fun login(user: String, pass: String) {
        if (user.isBlank() || pass.isBlank()) { _ui.update { it.copy(message = "Enter username and password.") }; return }
        _ui.update { it.copy(busy = true, message = null) }
        viewModelScope.launch {
            val r = lastFm.login(user.trim(), pass)
            _ui.update {
                it.copy(
                    busy = false,
                    lfUser = r.getOrNull() ?: it.lfUser,
                    message = r.exceptionOrNull()?.message?.let { m -> "Last.fm: $m" },
                )
            }
        }
    }

    fun logout() { lastFm.logout(); _ui.update { it.copy(lfUser = null, message = null) } }

    fun saveHost(url: String) {
        val ok = hosts.setCustom(url)
        _ui.update { it.copy(host = if (ok) url.trim() else it.host, message = if (ok) "Host saved." else "Host must start with https://") }
    }

    companion object {
        val Factory = viewModelFactory { initializer { SettingsViewModel(ServiceLocator.lastFm, ServiceLocator.hosts) } }
    }
}
