package org.melodyne.app.ui.settings

import android.content.SharedPreferences
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.melodyne.app.ai.AiConfig
import org.melodyne.app.ai.AiConfigStore
import org.melodyne.app.data.lastfm.LastFmClient
import org.melodyne.app.data.repo.HostStore
import org.melodyne.app.di.ServiceLocator
import org.melodyne.app.util.CrashLog

data class SettingsUi(
    val lfConfigured: Boolean,
    val lfUser: String?,
    val busy: Boolean = false,
    val message: String? = null,
    val host: String = "",
    val ai: AiConfig = AiConfig(),
    val crash: String? = null,
)

class SettingsViewModel(
    private val lastFm: LastFmClient,
    private val hosts: HostStore,
    private val aiStore: AiConfigStore,
    private val prefs: SharedPreferences,
) : ViewModel() {
    private val _ui = MutableStateFlow(
        SettingsUi(lastFm.configured, lastFm.loggedInUser, host = hosts.custom().orEmpty(), ai = aiStore.load(), crash = CrashLog.last(prefs))
    )
    val ui = _ui.asStateFlow()

    fun login(user: String, pass: String) {
        if (user.isBlank() || pass.isBlank()) { _ui.update { it.copy(message = "Enter your Last.fm username and password.") }; return }
        _ui.update { it.copy(busy = true, message = null) }
        viewModelScope.launch {
            val r = lastFm.login(user.trim(), pass)
            _ui.update {
                it.copy(
                    busy = false,
                    lfUser = r.getOrNull() ?: it.lfUser,
                    message = r.exceptionOrNull()?.message?.let { m -> "Last.fm: $m" },
                )
            }
        }
    }

    fun logout() { lastFm.logout(); _ui.update { it.copy(lfUser = null, message = null) } }

    fun saveHost(url: String) {
        val ok = hosts.setCustom(url)
        _ui.update { it.copy(host = if (ok) url.trim() else it.host, message = if (ok) "Music source saved." else "The host must start with https://") }
    }

    fun saveAi(url: String, key: String, model: String) {
        if (url.isNotBlank() && !url.trim().startsWith("https://")) {
            _ui.update { it.copy(message = "The AI base URL must start with https://") }
            return
        }
        val c = AiConfig(url.trim().trimEnd('/'), key.trim(), model.trim())
        aiStore.save(c)
        _ui.update { it.copy(ai = c, message = if (c.ready) "AI provider saved." else "Saved. Fill in all three fields to enable AI Mix.") }
    }

    fun clearCrash() { CrashLog.clear(prefs); _ui.update { it.copy(crash = null) } }

    companion object {
        val Factory = viewModelFactory {
            initializer { SettingsViewModel(ServiceLocator.lastFm, ServiceLocator.hosts, ServiceLocator.aiConfig, ServiceLocator.prefs) }
        }
    }
}
