package org.melodyne.app.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import org.melodyne.app.ui.Amoled
import org.melodyne.app.ui.LocalAccent
import org.melodyne.app.ui.Pill
import org.melodyne.app.ui.Txt

@Composable
fun SettingsScreen() {
    val vm: SettingsViewModel = viewModel(factory = SettingsViewModel.Factory)
    val s by vm.ui.collectAsState()
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var host by remember(s.host) { mutableStateOf(s.host) }

    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Txt("Settings", size = 28.sp, weight = FontWeight.ExtraBold)

        Txt("Last.fm scrobbling", size = 16.sp, weight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
        when {
            !s.lfConfigured -> Txt(
                "This build has no Last.fm API key. Rebuild with LASTFM_API_KEY and LASTFM_API_SECRET.",
                color = Amoled.Muted, maxLines = 4,
            )
            s.lfUser != null -> {
                Txt("Signed in as ${s.lfUser}", color = Amoled.Muted)
                Pill("Sign out", filled = false, onClick = vm::logout)
            }
            else -> {
                Field(user, { user = it }, "Last.fm username")
                Field(pass, { pass = it }, "Password", password = true)
                Pill(if (s.busy) "Signing in…" else "Sign in") { if (!s.busy) vm.login(user, pass) }
                Txt("Your password is sent once to Last.fm over HTTPS; only the session key is stored.", size = 12.sp, color = Amoled.Muted, maxLines = 3)
            }
        }

        Txt("API host", size = 16.sp, weight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
        Txt("Your own jiosaavn-api instance (https). Used first; leave empty for the built-in host.", size = 12.sp, color = Amoled.Muted, maxLines = 3)
        Field(host, { host = it }, "https://your-instance.example/api")
        Pill("Save host", filled = false) { vm.saveHost(host) }

        s.message?.let { Txt(it, color = LocalAccent.current, maxLines = 3) }
        Txt("Melodyne 0.1.0 · free software · no trackers", size = 12.sp, color = Amoled.Muted, modifier = Modifier.padding(top = 16.dp))
    }
}

@Composable
private fun Field(value: String, onChange: (String) -> Unit, hint: String, password: Boolean = false) {
    BasicTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        textStyle = TextStyle(color = Amoled.OnBg, fontSize = 16.sp),
        cursorBrush = SolidColor(LocalAccent.current),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else KeyboardType.Uri),
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Amoled.SurfaceHi).padding(16.dp),
        decorationBox = { inner ->
            Box {
                if (value.isEmpty()) Txt(hint, color = Amoled.Muted, size = 16.sp)
                inner()
            }
        },
    )
}
