package org.melodyne.app.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import org.melodyne.app.ui.Amoled
import org.melodyne.app.ui.Chip
import org.melodyne.app.ui.Field
import org.melodyne.app.ui.LocalAccent
import org.melodyne.app.ui.Panel
import org.melodyne.app.ui.Pill
import org.melodyne.app.ui.Txt

@Composable
fun SettingsScreen() {
    val vm: SettingsViewModel = viewModel(factory = SettingsViewModel.Factory)
    val s by vm.ui.collectAsState()
    val clipboard = LocalClipboardManager.current
    val uriHandler = LocalUriHandler.current
    var lfKey by remember(s.lfKey) { mutableStateOf(s.lfKey) }
    var lfSecret by remember(s.lfSecret) { mutableStateOf(s.lfSecret) }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var host by remember(s.host) { mutableStateOf(s.host) }
    var aiUrl by remember(s.ai) { mutableStateOf(s.ai.baseUrl) }
    var aiKey by remember(s.ai) { mutableStateOf(s.ai.apiKey) }
    var aiModel by remember(s.ai) { mutableStateOf(s.ai.model) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Txt("Settings", size = 28.sp, weight = FontWeight.ExtraBold)
        s.message?.let { Txt(it, color = LocalAccent.current, maxLines = 3, size = 14.sp, weight = FontWeight.SemiBold) }

        Panel("Last.fm scrobbling") {
            if (s.lfUser == null) {
                Txt(
                    "1. Get a free API key from Last.fm (any app name works).\n2. Paste the key and secret here.\n3. Sign in with your Last.fm account.",
                    size = 13.sp, color = Amoled.Muted, maxLines = 6,
                )
                Pill("Open Last.fm API page", filled = false) { uriHandler.openUri("https://www.last.fm/api/account/create") }
                if (s.lfBuiltIn && s.lfKey.isBlank()) Txt("This build already includes a key. You can skip to step 3.", size = 12.sp, color = Amoled.Muted)
                Field(lfKey, { lfKey = it }, "API key")
                Field(lfSecret, { lfSecret = it }, "Shared secret", password = true)
                Pill("Save key", filled = false) { vm.saveLastFmKeys(lfKey, lfSecret) }
            }
            if (s.lfConfigured) {
                if (s.lfUser != null) {
                    Chip("Signed in as ${s.lfUser}", true) {}
                    Pill("Sign out", filled = false, onClick = vm::logout)
                } else {
                    Field(user, { user = it }, "Last.fm username")
                    Field(pass, { pass = it }, "Password", password = true)
                    Pill(if (s.busy) "Signing in…" else "Sign in") { if (!s.busy) vm.login(user, pass) }
                    Txt("Your password goes to Last.fm once over HTTPS. Only the session key is kept.", size = 12.sp, color = Amoled.Muted, maxLines = 3)
                }
            }
            Txt(s.lfStatus, size = 12.sp, color = LocalAccent.current, maxLines = 3)
            Txt("A song scrobbles after half its length or four minutes. Failed scrobbles are retried later.", size = 12.sp, color = Amoled.Muted, maxLines = 3)
        }

        Panel("Custom source (optional)") {
            Txt(
                "Melodyne has a built-in music source. If you run a compatible server of your own, put its https address here and it will be tried first.",
                size = 13.sp, color = Amoled.Muted, maxLines = 5,
            )
            Field(host, { host = it }, "https://your-instance.example/api", keyboard = KeyboardType.Uri)
            Pill("Save", filled = false) { vm.saveHost(host) }
        }

        Panel("AI playlist provider") {
            Txt(
                "Any OpenAI-compatible service. Examples: https://openrouter.ai/api/v1 or https://api.groq.com/openai/v1. " +
                    "Your key stays on this phone; prompts go only to the provider you choose.",
                size = 13.sp, color = Amoled.Muted, maxLines = 6,
            )
            Field(aiUrl, { aiUrl = it }, "Base URL (https://…/v1)", keyboard = KeyboardType.Uri)
            Field(aiKey, { aiKey = it }, "API key", password = true)
            Field(aiModel, { aiModel = it }, "Model id from your provider")
            Pill("Save provider") { vm.saveAi(aiUrl, aiKey, aiModel) }
        }

        s.crash?.let { trace ->
            Panel("Last crash") {
                Txt(trace.take(900), size = 11.sp, color = Amoled.Err, maxLines = 14)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Pill("Copy") { clipboard.setText(AnnotatedString(trace)) }
                    Pill("Clear", filled = false, onClick = vm::clearCrash)
                }
            }
        }

        Panel("About") {
            Txt("Melodyne 0.4.0", size = 15.sp, weight = FontWeight.SemiBold)
            Txt("Free software. No trackers, no ads, no analytics, no accounts.", size = 12.sp, color = Amoled.Muted, maxLines = 3)
        }
    }
}
