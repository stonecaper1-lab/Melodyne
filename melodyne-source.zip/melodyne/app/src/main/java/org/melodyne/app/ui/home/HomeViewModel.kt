package org.melodyne.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.melodyne.app.data.local.RecentStore
import org.melodyne.app.data.repo.ApiUnavailable
import org.melodyne.app.di.ServiceLocator
import org.melodyne.app.domain.MusicRepository
import org.melodyne.app.domain.PlaylistInfo
import org.melodyne.app.domain.Song

/** Mood tiles on Home: label to catalogue search. */
val MOODS = listOf(
    "Chill" to "chill lofi hindi",
    "Workout" to "workout gym hits",
    "Romance" to "romantic hindi songs",
    "Party" to "party dance hits",
    "Focus" to "instrumental focus",
    "Retro" to "old hindi classics",
    "Sufi" to "sufi",
    "Punjabi" to "punjabi hits",
    "Devotional" to "bhajan devotional",
    "Sad" to "sad hindi songs",
)

data class HomeUi(
    val loading: Boolean = true,
    val trending: List<Song> = emptyList(),
    val playlists: List<PlaylistInfo> = emptyList(),
    val recents: List<Song> = emptyList(),
    val error: String? = null,
    val loadingMood: String? = null,
)

class HomeViewModel(private val repo: MusicRepository, private val recents: RecentStore) : ViewModel() {
    private val _ui = MutableStateFlow(HomeUi(recents = recents.all()))
    val ui = _ui.asStateFlow()

    init { load() }

    fun refreshRecents() = _ui.update { it.copy(recents = recents.all()) }

    fun load() {
        _ui.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            val songs = async { runCatching { repo.search("top hits") } }
            val lists = async { runCatching { repo.searchPlaylists("top") } }
            val s = songs.await()
            val p = lists.await()
            _ui.update {
                it.copy(
                    loading = false,
                    trending = s.getOrDefault(it.trending),
                    playlists = p.getOrDefault(it.playlists),
                    error = s.exceptionOrNull()?.let { e -> (e as? ApiUnavailable)?.userMessage ?: "Something went wrong." },
                )
            }
        }
    }

    fun playPlaylist(id: String, onReady: (List<Song>) -> Unit) {
        viewModelScope.launch {
            runCatching { repo.playlist(id) }
                .onSuccess { onReady(it.songs) }
                .onFailure { e ->
                    _ui.update { it.copy(error = (e as? ApiUnavailable)?.userMessage ?: "Couldn't open playlist.") }
                }
        }
    }

    fun playMood(label: String, query: String, onReady: (List<Song>) -> Unit) {
        if (_ui.value.loadingMood != null) return
        _ui.update { it.copy(loadingMood = label, error = null) }
        viewModelScope.launch {
            runCatching { repo.search(query) }
                .onSuccess { r -> _ui.update { it.copy(loadingMood = null) }; if (r.isNotEmpty()) onReady(r) }
                .onFailure { e ->
                    _ui.update { it.copy(loadingMood = null, error = (e as? ApiUnavailable)?.userMessage ?: "Couldn't load that mood.") }
                }
        }
    }

    companion object {
        val Factory = viewModelFactory { initializer { HomeViewModel(ServiceLocator.repo, ServiceLocator.recents) } }
    }
}
