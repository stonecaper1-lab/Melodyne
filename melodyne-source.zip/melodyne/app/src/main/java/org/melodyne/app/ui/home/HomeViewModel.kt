package org.melodyne.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.melodyne.app.data.local.RecentStore
import org.melodyne.app.data.repo.ApiUnavailable
import org.melodyne.app.di.ServiceLocator
import org.melodyne.app.domain.MusicRepository
import org.melodyne.app.domain.PlaylistInfo
import org.melodyne.app.domain.Song

data class HomeUi(
    val loading: Boolean = true,
    val trending: List<Song> = emptyList(),
    val playlists: List<PlaylistInfo> = emptyList(),
    val recents: List<Song> = emptyList(),
    val error: String? = null,
)

class HomeViewModel(private val repo: MusicRepository, private val recents: RecentStore) : ViewModel() {
    private val _ui = MutableStateFlow(HomeUi(recents = recents.all()))
    val ui = _ui.asStateFlow()

    init { load() }

    fun refreshRecents() = _ui.update { it.copy(recents = recents.all()) }

    fun load() {
        _ui.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            val songs = async { runCatching { repo.search("top hits") } }
            val lists = async { runCatching { repo.searchPlaylists("top") } }
            val s = songs.await()
            val p = lists.await()
            _ui.update {
                it.copy(
                    loading = false,
                    trending = s.getOrDefault(it.trending),
                    playlists = p.getOrDefault(it.playlists),
                    error = s.exceptionOrNull()?.let { e -> (e as? ApiUnavailable)?.userMessage ?: "Something went wrong." },
                )
            }
        }
    }

    fun playPlaylist(id: String, onReady: (List<Song>) -> Unit) {
        viewModelScope.launch {
            runCatching { repo.playlist(id) }
                .onSuccess { onReady(it.songs) }
                .onFailure { e ->
                    _ui.update { it.copy(error = (e as? ApiUnavailable)?.userMessage ?: "Couldn't open playlist.") }
                }
        }
    }

    companion object {
        val Factory = viewModelFactory { initializer { HomeViewModel(ServiceLocator.repo, ServiceLocator.recents) } }
    }
}
