package org.melodyne.app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import org.melodyne.app.player.PlayerConnection
import org.melodyne.app.ui.Amoled
import org.melodyne.app.ui.Cover
import org.melodyne.app.ui.ErrorCard
import org.melodyne.app.ui.SectionTitle
import org.melodyne.app.ui.SongRow
import org.melodyne.app.ui.Txt

@Composable
fun HomeScreen(conn: PlayerConnection, onOpenSearch: () -> Unit) {
    val vm: HomeViewModel = viewModel(factory = HomeViewModel.Factory)
    val s by vm.ui.collectAsState()
    LaunchedEffect(Unit) { vm.refreshRecents() }

    LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Txt("Melodyne", size = 30.sp, weight = FontWeight.ExtraBold)
                Txt(
                    "Search songs, artists, albums…", size = 15.sp, color = Amoled.Muted,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(Amoled.SurfaceHi)
                        .clickable(onClick = onOpenSearch).padding(horizontal = 18.dp, vertical = 14.dp),
                )
            }
        }
        s.error?.let { msg -> item { ErrorCard(msg, onRetry = vm::load) } }

        if (s.recents.isNotEmpty()) {
            item { SectionTitle("Recently played") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    itemsIndexed(s.recents) { i, song ->
                        Column(Modifier.size(width = 120.dp, height = 168.dp).clickable { conn.play(s.recents, i) }) {
                            Cover(song.thumbUrl, Modifier.size(120.dp), radius = 12.dp)
                            Txt(song.title, Modifier.padding(top = 6.dp), size = 13.sp, weight = FontWeight.Medium)
                            Txt(song.artist, size = 11.sp, color = Amoled.Muted)
                        }
                    }
                }
            }
        }

        if (s.playlists.isNotEmpty()) {
            item { SectionTitle("Playlists") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(s.playlists) { pl ->
                        Column(Modifier.size(width = 140.dp, height = 188.dp).clickable {
                            vm.playPlaylist(pl.id) { songs -> conn.play(songs, 0) }
                        }) {
                            Cover(pl.artUrl, Modifier.size(140.dp), radius = 12.dp)
                            Txt(pl.name, Modifier.padding(top = 6.dp), size = 13.sp, weight = FontWeight.Medium)
                        }
                    }
                }
            }
        }

        item { SectionTitle("Trending") }
        if (s.loading && s.trending.isEmpty()) item { Txt("Loading…", Modifier.padding(20.dp), color = Amoled.Muted) }
        itemsIndexed(s.trending) { i, song -> SongRow(song) { conn.play(s.trending, i) } }
    }
}
