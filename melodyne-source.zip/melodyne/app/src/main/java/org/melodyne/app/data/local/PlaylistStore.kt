package org.melodyne.app.data.local

import android.content.SharedPreferences
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import org.melodyne.app.domain.Song

@Serializable
data class SavedPlaylist(val id: String, val name: String, val prompt: String, val songs: List<Song>)

/** Saved AI mixes, kept on-device as JSON (max 20). */
class PlaylistStore(private val prefs: SharedPreferences, private val json: Json) {
    private val ser = ListSerializer(SavedPlaylist.serializer())

    fun all(): List<SavedPlaylist> = runCatching {
        json.decodeFromString(ser, prefs.getString(KEY, null) ?: "[]")
    }.getOrDefault(emptyList())

    fun save(p: SavedPlaylist) = write((listOf(p) + all().filterNot { it.id == p.id }).take(20))
    fun delete(id: String) = write(all().filterNot { it.id == id })

    private fun write(list: List<SavedPlaylist>) {
        prefs.edit().putString(KEY, json.encodeToString(ser, list)).apply()
    }

    private companion object { const val KEY = "saved_playlists" }
}
