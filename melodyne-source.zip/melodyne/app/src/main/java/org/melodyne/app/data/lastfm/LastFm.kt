package org.melodyne.app.data.lastfm

import android.content.SharedPreferences
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.FieldMap
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST
import java.security.MessageDigest

interface LastFmApi {
    @FormUrlEncoded
    @POST("2.0/")
    suspend fun post(@FieldMap fields: Map<String, String>): Response<ResponseBody>
}

/** Last.fm request signing: md5 of name+value pairs sorted by name, followed by the shared secret. */
object LastFmSigner {
    fun sign(params: Map<String, String>, secret: String): String {
        val base = params.filterKeys { it != "format" && it != "callback" }
            .toSortedMap()
            .entries.joinToString("") { it.key + it.value } + secret
        return MessageDigest.getInstance("MD5").digest(base.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
}

/** Only the session key is stored, never the password. */
class SessionStore(private val prefs: SharedPreferences) {
    val user: String? get() = prefs.getString("lf_user", null)
    val key: String? get() = prefs.getString("lf_sk", null)
    fun save(user: String, key: String) = prefs.edit().putString("lf_user", user).putString("lf_sk", key).apply()
    fun clear() = prefs.edit().remove("lf_user").remove("lf_sk").apply()
}

class LastFmClient(
    private val api: LastFmApi,
    private val store: SessionStore,
    private val apiKey: String,
    private val secret: String,
) {
    val configured: Boolean get() = apiKey.isNotBlank() && secret.isNotBlank()
    val loggedInUser: String? get() = store.user?.takeIf { store.key != null }

    private suspend fun signed(params: Map<String, String>): JsonObject? {
        val p = params + ("api_key" to apiKey)
        val body = p + ("api_sig" to LastFmSigner.sign(p, secret)) + ("format" to "json")
        val r = api.post(body)
        val txt = (if (r.isSuccessful) r.body() else r.errorBody())?.string().orEmpty()
        return runCatching { Json.parseToJsonElement(txt).jsonObject }.getOrNull()
    }

    /** Mobile auth flow: exchanges username+password once for a long-lived session key. */
    suspend fun login(user: String, pass: String): Result<String> = runCatching {
        check(configured) { "Last.fm API key/secret not set at build time" }
        val o = signed(mapOf("method" to "auth.getMobileSession", "username" to user, "password" to pass))
            ?: error("No response from Last.fm")
        if (o["error"] != null) error(o["message"]?.jsonPrimitive?.content ?: "Login failed")
        val s = o["session"]?.jsonObject ?: error("Unexpected response")
        val name = s["name"]!!.jsonPrimitive.content
        store.save(name, s["key"]!!.jsonPrimitive.content)
        name
    }

    fun logout() = store.clear()

    suspend fun nowPlaying(artist: String, track: String, album: String?, durationSec: Int) {
        val sk = store.key ?: return
        if (!configured || artist.isBlank() || track.isBlank()) return
        val p = mutableMapOf("method" to "track.updateNowPlaying", "artist" to artist, "track" to track, "sk" to sk)
        album?.takeIf { it.isNotBlank() }?.let { p["album"] = it }
        if (durationSec > 0) p["duration"] = durationSec.toString()
        runCatching { signed(p) }
    }

    suspend fun scrobble(artist: String, track: String, album: String?, startedAtSec: Long, durationSec: Int) {
        val sk = store.key ?: return
        if (!configured || artist.isBlank() || track.isBlank()) return
        val p = mutableMapOf(
            "method" to "track.scrobble", "artist" to artist, "track" to track,
            "timestamp" to startedAtSec.toString(), "sk" to sk,
        )
        album?.takeIf { it.isNotBlank() }?.let { p["album"] = it }
        if (durationSec > 0) p["duration"] = durationSec.toString()
        runCatching { signed(p) } // a failed scrobble is dropped, not queued (see README)
    }
}
