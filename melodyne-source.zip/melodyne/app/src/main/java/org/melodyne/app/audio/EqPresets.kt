package org.melodyne.app.audio

import kotlin.math.ln

/** Every preset is a gain curve (dB) on these anchor frequencies; device bands are interpolated from it. */
val EQ_ANCHORS = listOf(60f, 230f, 910f, 3600f, 14000f)

data class EqPreset(
    val id: String,
    val name: String,
    val blurb: String,
    /** dB at [EQ_ANCHORS]. */
    val gains: List<Float>,
    /** BassBoost strength 0..1000. */
    val bass: Int = 0,
    /** Virtualizer (spatial widening) strength 0..1000. */
    val surround: Int = 0,
    /** LoudnessEnhancer target gain in millibels. */
    val loudnessMb: Int = 0,
) {
    /** Gain in dB at [hz], linear in log-frequency between anchors. */
    fun gainAt(hz: Float): Float {
        if (hz <= EQ_ANCHORS.first()) return gains.first()
        if (hz >= EQ_ANCHORS.last()) return gains.last()
        val i = EQ_ANCHORS.indexOfLast { it <= hz }
        val x0 = ln(EQ_ANCHORS[i]); val x1 = ln(EQ_ANCHORS[i + 1])
        val t = (ln(hz) - x0) / (x1 - x0)
        return gains[i] + (gains[i + 1] - gains[i]) * t
    }
}

object EqPresets {
    val all = listOf(
        EqPreset("flat", "Flat", "Untouched signal. The reference to compare everything else against.",
            listOf(0f, 0f, 0f, 0f, 0f)),
        EqPreset("signature", "Signature", "Warm low end, forward vocals and a little air. Our everyday sound.",
            listOf(2.5f, 1f, 0f, 2f, 2.5f), bass = 150),
        EqPreset("bass_drive", "Bass Drive", "Deep sub and punchy kick for hip-hop, EDM and big film numbers.",
            listOf(6f, 4f, -1f, 0.5f, 1.5f), bass = 500, loudnessMb = 200),
        EqPreset("vocal", "Vocal Clarity", "Trims low-end mud and lifts 1–4 kHz, where voices live.",
            listOf(-3f, -1.5f, 2f, 4f, 1f)),
        EqPreset("sparkle", "Bollywood Sparkle", "Bright playback vocals, crisp tabla and shimmering strings.",
            listOf(1.5f, 0f, 1.5f, 4f, 4.5f)),
        EqPreset("unplugged", "Unplugged", "Woody body for guitar, ghazal and acoustic sets.",
            listOf(1.5f, 3.5f, 1.5f, 0.5f, -1.5f)),
        EqPreset("late_night", "Late Night", "Keeps detail at low volume: lifted bass and treble plus a touch of loudness.",
            listOf(4f, 1.5f, -1f, 1.5f, 3f), loudnessMb = 300),
        EqPreset("wide", "Wide Stage", "Headphone spatial widening with gentle sparkle on top.",
            listOf(1f, 0f, -0.5f, 1f, 2.5f), surround = 650),
        EqPreset("soft_treble", "Soft Treble", "Tames harsh, hissy or sibilant recordings by easing the top end.",
            listOf(1f, 1f, 0f, -2.5f, -4.5f)),
        EqPreset("pocket", "Pocket Speaker", "For phone speakers: drops sub-bass they can't play, boosts the mids that carry.",
            listOf(-5f, 2f, 3.5f, 3f, 1f), loudnessMb = 600),
    )

    fun byId(id: String): EqPreset = all.firstOrNull { it.id == id } ?: all.first()
}
