package org.melodyne.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import kotlinx.coroutines.runBlocking
import org.junit.Test
import org.melodyne.app.ai.AiClient
import org.melodyne.app.audio.CrossfadeCurve
import org.melodyne.app.audio.EQ_BANDS
import org.melodyne.app.audio.Tpdf
import org.melodyne.app.player.SleepTimer
import org.melodyne.app.player.SleepUi
import org.melodyne.app.ui.skins.SevenSegments
import org.melodyne.app.ui.skins.Skins
import org.melodyne.app.ui.skins.mmss
import org.melodyne.app.widget.WidgetMath
import org.melodyne.app.audio.Loudness
import org.melodyne.app.audio.PlaybackState
import org.melodyne.app.data.repo.AlbumService
import org.melodyne.app.data.repo.CloudBuilder
import org.melodyne.app.data.update.UpdateChecker
import org.melodyne.app.player.BitrateSeries
import org.melodyne.app.audio.EqMath
import org.melodyne.app.audio.EqPresets
import org.melodyne.app.data.catalog.StreamCrypto
import org.melodyne.app.data.lastfm.LastFmSigner
import org.melodyne.app.data.lastfm.ScrobbleText
import org.melodyne.app.domain.LibraryData
import org.melodyne.app.domain.Lyrics
import org.melodyne.app.domain.MusicRepository
import org.melodyne.app.domain.LibraryOps
import org.melodyne.app.domain.LrcParser
import org.melodyne.app.domain.PlayStat
import org.melodyne.app.domain.Refine
import org.melodyne.app.domain.Song
import org.melodyne.app.domain.SmartLists
import org.melodyne.app.domain.StreamPicker
import org.melodyne.app.domain.UserPlaylist

private fun song(id: String, title: String, artist: String = "Artist", dur: Int = 200, kbps: Int = 320) =
    Song(id, title, artist, "", dur, null, null, "https://x.test/$id.mp4", kbps, false)

class CoreTest {
    // ---- streams, lyrics, scrobbling ----
    @Test fun picksHighestBitrateAndForcesHttps() {
        val r = StreamPicker.pick(listOf(
            "12kbps" to "http://c/12.mp4", "320kbps" to "http://c/320.mp4",
            "96kbps" to "http://c/96.mp4", "160kbps" to "http://c/160.mp4",
        ))
        assertEquals("https://c/320.mp4" to 320, r)
    }

    @Test fun fallsBackToBestAvailableAndHandlesEmpty() {
        assertEquals("https://c/160.mp4" to 160, StreamPicker.pick(listOf("48kbps" to "https://c/48.mp4", "160kbps" to "https://c/160.mp4")))
        assertNull(StreamPicker.pick(emptyList()))
        assertNull(StreamPicker.pick(listOf("320kbps" to "")))
    }

    @Test fun parsesSyncedLrc() {
        val l = LrcParser.parse("[ar:X]\n[00:01.50]Hello\n[00:05.00]World\n[01:00.25]Bye")
        assertTrue(l.synced)
        assertEquals(1500L, l.lines[0].timeMs)
        assertEquals(60250L, l.lines[2].timeMs)
    }

    @Test fun plainLyricsStayPlain() {
        val l = LrcParser.parse("Line one<br>Line two")
        assertFalse(l.synced)
        assertEquals("Line one\nLine two", l.plain)
    }

    @Test fun lastFmSignatureSortsParamsAndIgnoresFormat() {
        assertEquals("1d0396bcbc2c54e569e7af9cf9c4685e", LastFmSigner.sign(mapOf("b" to "2", "a" to "1", "format" to "json"), "s"))
    }

    @Test fun decryptsStreamUrlAndPicks320() {
        val url = StreamCrypto.decrypt("uWha1yBeBEQNMTtLk+2Rs64AiVvJ5+3ESS71sWbL17qQPNKUa/7R1A==")
        assertEquals("http://cdn.example.com/123/abc_96.mp4", url)
        assertEquals("https://cdn.example.com/123/abc_320.mp4", StreamCrypto.withBitrate(url!!, 320))
        assertNull(StreamCrypto.decrypt("not-base64-!!"))
    }

    @Test fun scrobbleTextStripsDecorations() {
        assertEquals("Tum Hi Ho", ScrobbleText.title("Tum Hi Ho (From \"Aashiqui 2\")"))
        assertEquals("Kesariya", ScrobbleText.title("Kesariya [feat. Someone]"))
        assertEquals("Dil Chahta Hai (Remix)", ScrobbleText.title("Dil Chahta Hai (Remix)"))
        assertEquals("Arijit Singh", ScrobbleText.artist("Arijit Singh, Shreya Ghoshal"))
    }

    @Test fun aiReplyParsingToleratesProseAndFences() {
        val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
        val reply = """Sure! Here you go:
```json
[{"title":"Tum Hi Ho","artist":"Arijit Singh"},{"title":"tum hi ho","artist":"arijit singh"},{"title":"","artist":"x"}]
```"""
        val r = AiClient.parse(reply, json)
        assertEquals(1, r.size)
        assertEquals("Tum Hi Ho", r[0].title)
        assertTrue(AiClient.parse("no json here", json).isEmpty())
    }

    // ---- equalizer ----
    @Test fun sevenBandsAndPresetsAreConsistent() {
        assertEquals(7, EQ_BANDS.size)
        EqPresets.all.forEach { assertEquals(it.id, 7, it.gains.size) }
        assertEquals(EqPresets.all.size, EqPresets.all.map { it.id }.toSet().size)
        assertTrue(EqPresets.byId("flat").gains.all { it == 0f })
        assertEquals("flat", EqPresets.byId("nope").id)
    }

    @Test fun filterHitsRequestedGainAndHeadroomMatchesPeak() {
        val fs = 44100.0
        assertEquals(6.0, EqMath.magnitudeDb(EqMath.design(3, 6f, fs), 1000.0, fs), 0.05)
        assertEquals(0.0, EqMath.headroomDb(List(7) { 0f }), 0.0)
        assertEquals(6.0, EqMath.headroomDb(listOf(0f, 0f, 0f, 6f, 0f, 0f, 0f)), 0.15)
        assertEquals(0.0, EqMath.headroomDb(listOf(-3f, -2f, 0f, 0f, 0f, 0f, -4f)), 0.001)   // cuts need no headroom
    }

    // ---- search de-duplication ----
    @Test fun duplicateVersionsCollapseButRealVersionsStay() {
        val raw = listOf(
            song("1", "Tum Hi Ho (From \"Aashiqui 2\")", "Arijit Singh", 262, 160),
            song("2", "Tum Hi Ho", "Arijit Singh, Mithoon", 263, 320),
            song("3", "Tum Hi Ho (Reprise)", "Arijit Singh", 150),
            song("4", "Tum Hi Ho (Lofi)", "Arijit Singh", 262),
            song("5", "Tum Hi Ho", "Someone Else", 262),
        )
        val out = Refine.songs("tum hi ho", raw)
        assertEquals(listOf("2", "5", "3", "4"), out.map { it.id })       // 1 merged into 2 (better bitrate kept)
    }

    @Test fun exactTitleMatchesRankFirst() {
        val out = Refine.songs("kesariya", listOf(song("a", "Other Song"), song("b", "Kesariya Reprise", dur = 100), song("c", "Kesariya", dur = 270)))
        assertEquals("c", out.first().id)
    }

    // ---- library ----
    @Test fun addSongsSkipsDuplicatesAndMoveReorders() {
        val a = song("a", "A"); val b = song("b", "B"); val c = song("c", "C")
        assertEquals(listOf("a", "b", "c"), LibraryOps.addSongs(listOf(a, b), listOf(b, c)).map { it.id })
        assertEquals(listOf("b", "c", "a"), LibraryOps.move(listOf(a, b, c), 0, 2).map { it.id })
        assertEquals(listOf(a, b, c), LibraryOps.move(listOf(a, b, c), 5, 0))
    }

    @Test fun playsAreCountedPerTimeOfDay() {
        val s = song("a", "A")
        var stats = LibraryOps.recordPlay(emptyList(), s, 1_000L, hour = 23)
        stats = LibraryOps.recordPlay(stats, s, 2_000L, hour = 1)
        stats = LibraryOps.recordPlay(stats, s, 3_000L, hour = 9)
        assertEquals(1, stats.size)
        assertEquals(3, stats[0].plays); assertEquals(2, stats[0].night); assertEquals(1, stats[0].morning)
        assertEquals(1_000L, stats[0].first); assertEquals(3_000L, stats[0].last)
    }

    @Test fun smartPlaylistsBuildFromHabits() {
        val day = 86_400_000L
        val now = 100 * day
        fun st(id: String, plays: Int, ageDays: Int, dur: Int = 240, night: Int = 0, artist: String = "X") =
            PlayStat(song(id, "T$id", artist, dur), plays, 0, now - ageDays * day, night = night)
        val stats = listOf(
            st("1", 9, 1, night = 9), st("2", 7, 30, night = 7), st("3", 5, 40, night = 5),
            st("4", 2, 60, dur = 150), st("5", 1, 2, dur = 180), st("6", 1, 3, dur = 400),
        )
        val lists = SmartLists.build(stats, now).associateBy { it.id }
        assertEquals(listOf("1", "2", "3", "4", "5", "6"), lists.getValue("most").songs.map { it.id })
        assertEquals(listOf("2", "3", "4"), lists.getValue("rediscover").songs.map { it.id })   // 2+ plays, idle > 14 days
        assertEquals(listOf("1", "2", "3"), lists.getValue("night").songs.map { it.id })
        assertTrue("short" !in lists || lists.getValue("short").songs.size >= 3)
        assertTrue(SmartLists.build(emptyList(), now).isEmpty())
    }

    @Test fun importMergesWithoutDuplicatingOrLosingNewerEdits() {
        val a = UserPlaylist("p1", "Old name", 1, 10, listOf(song("a", "A")))
        val aNewer = a.copy(name = "New name", updatedAt = 20)
        val b = UserPlaylist("p2", "Other", 1, 5)
        val (merged, changed) = LibraryOps.merge(LibraryData(listOf(a)), LibraryData(listOf(aNewer, b)))
        assertEquals(2, changed)
        assertEquals(listOf("New name", "Other"), merged.playlists.map { it.name })
        val (again, none) = LibraryOps.merge(merged, LibraryData(listOf(a)))        // an older copy must not win
        assertEquals(0, none)
        assertEquals("New name", again.playlists.first().name)
    }

    // ---- loudness, audiophile, updates ----
    @Test fun kWeightingMatchesTheItuReferenceAt48k() {
        val s1 = Loudness.stage1(48000.0)
        assertEquals(1.535125, s1[0], 1e-5); assertEquals(-2.691696, s1[1], 1e-5); assertEquals(1.198393, s1[2], 1e-5)
        assertEquals(-1.690659, s1[3], 1e-5); assertEquals(0.732481, s1[4], 1e-5)
        val s2 = Loudness.stage2(48000.0)
        assertEquals(-1.990047, s2[3], 1e-5); assertEquals(0.990072, s2[4], 1e-5)
    }

    @Test fun normalisationGainIsClampedAndPeakAware() {
        assertEquals(-6.0, Loudness.gainDb(-8.0, 0.5), 1e-9)                 // louder than target: turn down
        assertEquals(3.0, Loudness.gainDb(-20.0, 0.1), 1e-9)                 // quiet but safe: boost, capped at +3 dB
        assertEquals(-12.0, Loudness.gainDb(5.0, 0.5), 1e-9)                 // absurdly loud: floor at -12 dB
        assertEquals(0.415, Loudness.gainDb(-20.0, 0.9), 0.01)               // a hot peak limits the boost
    }

    @Test fun audiophileModeAlwaysSwitchesNormalisationOff() {
        assertTrue(PlaybackState(audiophile = false, normalize = true).normalizeEffective)
        assertFalse(PlaybackState(audiophile = true, normalize = true).normalizeEffective)
        assertFalse(PlaybackState(audiophile = false, normalize = false).normalizeEffective)
    }

    @Test fun versionComparisonIsNumericNotAlphabetic() {
        assertTrue(UpdateChecker.isNewer("v0.10.0", "0.9.4"))
        assertTrue(UpdateChecker.isNewer("0.5.0", "0.4.0"))
        assertTrue(UpdateChecker.isNewer("1.0", "0.9.9"))
        assertFalse(UpdateChecker.isNewer("0.5.0", "0.5.0"))
        assertFalse(UpdateChecker.isNewer("v0.4.9", "0.5.0"))
        assertFalse(UpdateChecker.isNewer("0.5", "0.5.0"))
    }

    // ---- live bitrate, crossfade, genre cloud ----
    @Test fun bitrateIsCountedFromFramesAndNeverDoubleCounts() {
        val cbr = BitrateSeries()
        repeat(2) { for (n in 0 until 430) cbr.record(n * 23_220L, 929) }          // 10 s of 320 kbps AAC at 44.1 kHz, fed twice (a seek)
        assertEquals(320.0, cbr.kbpsAt(4000)!!.toDouble(), 4.0)
        assertEquals(320.0, cbr.averageKbps()!!.toDouble(), 4.0)
        val vbr = BitrateSeries()
        for (n in 0 until 430) vbr.record(n * 23_220L, if (n in 88..128) 1400 else 700)
        assertTrue(vbr.kbpsAt(2500)!! > vbr.kbpsAt(7000)!! + 100)                    // the dense second really reads higher
        assertNull(BitrateSeries().kbpsAt(1000))
        assertTrue(cbr.recent(8000, 5).size == 5)
    }

    @Test fun crossfadeCurvesKeepLevelAndHitTheEnds() {
        for (i in 0..10) {
            val (inc, out) = CrossfadeCurve.gains(i / 10f, equalPower = true)
            assertEquals(1.0, (inc * inc + out * out).toDouble(), 1e-5)               // equal power: constant loudness
            val (li, lo) = CrossfadeCurve.gains(i / 10f, equalPower = false)
            assertEquals(1.0, (li + lo).toDouble(), 1e-6)
        }
        assertEquals(0f, CrossfadeCurve.gains(0f, true).first, 1e-6f)
        assertEquals(0f, CrossfadeCurve.gains(1f, true).second, 1e-6f)
    }

    @Test fun genreCloudDropsNoiseKeepsRealGenresAndAddsLocalOnes() {
        val tags = CloudBuilder.build(listOf("rock" to 1000L, "seen live" to 900L, "electronic" to 100L, "2010" to 50L, "Favorites" to 40L))
        val names = tags.map { it.name }
        assertFalse("seen live" in names); assertFalse("2010" in names); assertFalse("favorites" in names)
        assertTrue("rock" in names && "electronic" in names && "bollywood" in names && "sufi" in names)
        assertEquals(1f, tags.first { it.name == "rock" }.weight, 1e-6f)
        assertTrue(tags.all { it.weight in 0f..1f })
        assertEquals(names, CloudBuilder.build(listOf("rock" to 1000L, "seen live" to 900L, "electronic" to 100L, "2010" to 50L, "Favorites" to 40L)).map { it.name })
        assertTrue(CloudBuilder.sizeSp(1f) > CloudBuilder.sizeSp(0.2f))
    }

    // ---- album and composer ----
    @Test fun albumFallsBackToNameSearchWhenTheIdYieldsNothing() = runBlocking {
        val songs = listOf(song("1", "A").copy(album = "Aashiqui 2"), song("2", "B").copy(album = "Aashiqui 2"), song("3", "C").copy(album = "Other"))
        val repo = object : MusicRepository {
            override suspend fun search(query: String) = songs
            override suspend fun lyrics(songId: String): Lyrics? = null
            override suspend fun albumSongs(albumId: String): List<Song> = emptyList()
        }
        assertEquals(listOf("1", "2"), AlbumService(repo).tracks(songs[0].copy(albumId = "x")).map { it.id })
    }

    @Test fun composerCreditsSplitIntoSeparateNames() {
        assertEquals(setOf("pritam", "mithoon"), org.melodyne.app.domain.TitleText.artistKeys("Pritam, Mithoon"))
        assertEquals("", song("1", "A").composer)                       // old saved songs default to "no composer"
    }

    // ---- fidelity helpers and skins ----
    @Test fun gentleNormalisationNeverBoostsAndPlrIsPeakOverLoudness() {
        assertEquals(0.0, Loudness.gainDb(-20.0, 0.1, 0.0), 1e-9)
        assertEquals(-6.0, Loudness.gainDb(-8.0, 0.5, 0.0), 1e-9)
        assertEquals(8.7, Loudness.plr(-9.0, 0.966), 0.1)
    }

    @Test fun ditherIsCentredAndBounded() {
        val d = Tpdf()
        var sum = 0.0
        repeat(100_000) { val v = d.next(); assertTrue(v > -1.0 && v < 1.0); sum += v }
        assertEquals(0.0, sum / 100_000, 0.02)
    }

    @Test fun skinsAreUniqueAndUnknownIdsFallBackToLiquid() {
        assertEquals(Skins.ALL.size, Skins.ALL.map { it.id }.toSet().size)
        assertEquals("liquid", Skins.byId("nope").id)
        assertTrue(Skins.ALL.map { it.id }.containsAll(listOf("liquid", "amp", "tape", "deck")))
    }

    // ---- skins and widget helpers ----
    @Test fun sevenSegmentDigitsLightTheRightSegments() {
        assertEquals("abcdefg", SevenSegments.segmentsFor('8'))
        assertEquals("bc", SevenSegments.segmentsFor('1'))
        assertEquals("g", SevenSegments.segmentsFor('-'))
        assertEquals("", SevenSegments.segmentsFor('x'))
    }

    @Test fun clocksAndWidgetProgressBehave() {
        assertEquals("03:07", mmss(187_000)); assertEquals("00:00", mmss(0)); assertEquals("01:05", mmss(-65_000))
        assertEquals(250, WidgetMath.progress(50, 200)); assertEquals(1000, WidgetMath.progress(500, 200)); assertEquals(0, WidgetMath.progress(5, 0))
        assertEquals("3:07", WidgetMath.clock(187_000))
    }

    // ---- sleep timer ----
    @Test fun sleepFadeAndLabelsBehave() {
        assertEquals(1f, SleepTimer.fadeFactor(60_000), 1e-6f)
        assertEquals(0.5f, SleepTimer.fadeFactor(10_000), 1e-6f)
        assertEquals(0f, SleepTimer.fadeFactor(0), 1e-6f)
        assertEquals("12:34", SleepUi(endAt = 1, remainingMs = 754_000).label())
        assertEquals("End of this song", SleepUi(endOfSong = true).label())
        assertTrue(SleepUi(endOfSong = true).active); assertFalse(SleepUi().active)
    }
}
