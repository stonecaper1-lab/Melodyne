package org.melodyne.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.melodyne.app.data.lastfm.LastFmSigner
import org.melodyne.app.data.direct.JioCrypto
import org.melodyne.app.domain.LrcParser
import org.melodyne.app.domain.StreamPicker

class CoreTest {
    @Test fun picksHighestBitrateAndForcesHttps() {
        val r = StreamPicker.pick(listOf(
            "12kbps" to "http://c/12.mp4", "320kbps" to "http://c/320.mp4",
            "96kbps" to "http://c/96.mp4", "160kbps" to "http://c/160.mp4",
        ))
        assertEquals("https://c/320.mp4" to 320, r)
    }

    @Test fun fallsBackToBestAvailableAndHandlesEmpty() {
        assertEquals("https://c/160.mp4" to 160, StreamPicker.pick(listOf("48kbps" to "https://c/48.mp4", "160kbps" to "https://c/160.mp4")))
        assertNull(StreamPicker.pick(emptyList()))
        assertNull(StreamPicker.pick(listOf("320kbps" to "")))
    }

    @Test fun parsesSyncedLrc() {
        val l = LrcParser.parse("[ar:X]\n[00:01.50]Hello\n[00:05.00]World\n[01:00.25]Bye")
        assertTrue(l.synced)
        assertEquals(1500L, l.lines[0].timeMs)
        assertEquals(60250L, l.lines[2].timeMs)
        assertEquals("Bye", l.lines[2].text)
    }

    @Test fun plainLyricsStayPlain() {
        val l = LrcParser.parse("Line one<br>Line two")
        assertFalse(l.synced)
        assertEquals("Line one\nLine two", l.plain)
    }

    @Test fun lastFmSignatureSortsParamsAndIgnoresFormat() {
        assertEquals("1d0396bcbc2c54e569e7af9cf9c4685e", LastFmSigner.sign(mapOf("b" to "2", "a" to "1", "format" to "json"), "s"))
    }

    @Test fun decryptsJioSaavnStreamUrlAndPicks320() {
        // Vector produced with: openssl enc -des-ecb -K 3338333436353931 (key "38346591")
        val enc = "iPPGVzyogeiPwpro65A0eUaQggN+8+J4LZ3AJQNq3T7xWSofYfNw/Q=="
        val url = JioCrypto.decrypt(enc)
        assertEquals("http://aac.saavncdn.com/123/abc_96.mp4", url)
        assertEquals("https://aac.saavncdn.com/123/abc_320.mp4", JioCrypto.withBitrate(url!!, 320))
        assertNull(JioCrypto.decrypt("not-base64-!!"))
    }
}
