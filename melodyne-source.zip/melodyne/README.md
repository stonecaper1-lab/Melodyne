# Melodyne

Tiny FOSS JioSaavn client. Kotlin + Jetpack Compose (no Material), Media3/ExoPlayer, Retrofit/OkHttp.
No Firebase, no Google Play Services, no analytics.

## Get an APK (no local Android SDK needed)
1. Push this folder to a GitHub repo (branch `main`).
2. Optional secrets: `LASTFM_API_KEY`, `LASTFM_API_SECRET` (scrobbling), `KEYSTORE_B64` (+ `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`) for a stable signing key.
3. `git tag v0.1.0 && git push --tags` -> the APK appears at
   `https://github.com/<you>/<repo>/releases/latest/download/melodyne.apk`.
   (Plain pushes upload it as a workflow artifact instead.)

The workflow runs unit tests, builds with R8, and **fails if the APK is >= 5,000,000 bytes**.

Local: `gradle :app:assembleRelease` (Gradle 8.9, JDK 17, Android SDK 34).

## Design notes
- **Streams**: `StreamPicker` takes the highest bitrate in `downloadUrl` (320 kbps AAC/MP4), forced to https.
- **402 / outages**: `SaavnRepository` tries each host, puts hosts that return 402/429/5xx on a 5 min cooldown,
  then serves the last cached answer. Add your own instance in Settings (self-host sumitkolhe/jiosaavn-api).
- **Quality badge**: `QualityMonitor` (service) reads ExoPlayer's decoder-input `Format` and publishes it via
  MediaSession extras; `PlayerConnection` (UI) receives it. Green dot = measured from the stream, amber = API label only.
  The bitrate is snapped to the nearest tier (12/48/96/160/320) when within 10 %.
- **Scrobbling**: after 50 % of the track or 4 min of listening (tracks > 30 s). Failed scrobbles are dropped, not queued.
- **Size**: arm64-v8a only, English resources only, no Material3/icon libs, vector-only icon, R8 + resource shrinking.

## Known gaps
- Never compiled or run by the author of this scaffold; first CI run may need small fixes.
- Lyrics path `songs/{id}/lyrics` is unverified against sumitkolhe/jiosaavn-api; edit `SaavnRepository.lyrics()` if needed.
- No offline scrobble queue; session key is stored in plain SharedPreferences.
