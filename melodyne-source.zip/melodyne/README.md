# Melodyne

Tiny FOSS JioSaavn client. Kotlin + Jetpack Compose (no Material), Media3/ExoPlayer, Retrofit/OkHttp.
No Firebase, no Google Play Services, no analytics.

## Get an APK (no local Android SDK needed)
1. Push this folder to a GitHub repo (branch `main`).
2. Optional secrets: `LASTFM_API_KEY`, `LASTFM_API_SECRET` (scrobbling), `KEYSTORE_B64` (+ `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`) for a stable signing key.
3. `git tag v0.1.0 && git push --tags` -> the APK appears at
   `https://github.com/<you>/<repo>/releases/latest/download/melodyne.apk`.
   (Plain pushes upload it as a workflow artifact instead.)

The workflow runs unit tests, builds with R8, and **fails if the APK is >= 5,000,000 bytes**.

Local: `gradle :app:assembleRelease` (Gradle 8.9, JDK 17, Android SDK 34).

## Design notes
- **Streams**: `StreamPicker` takes the highest bitrate in `downloadUrl` (320 kbps AAC/MP4), forced to https.
- **Sources** (`ChainRepository`): your own host from Settings (if set) -> JioSaavn's own web API directly
  (`DirectJioRepository`, stream URLs decrypted in `JioCrypto`, 320 kbps requested) -> public hosted API.
  Every failure is listed in the red error card so you can see which host broke and why.
- **Signing**: `app/melodyne-dev.jks` is a PUBLIC dev key so new builds install over old ones. Replace it
  (or set the KEYSTORE_* secrets) before distributing builds.
- **402 / outages**: `SaavnRepository` tries each host, puts hosts that return 402/429/5xx on a 5 min cooldown,
  then serves the last cached answer. Add your own instance in Settings (self-host sumitkolhe/jiosaavn-api).
- **Quality badge**: `QualityMonitor` (service) reads ExoPlayer's decoder-input `Format` and publishes it via
  MediaSession extras; `PlayerConnection` (UI) receives it. Green dot = measured from the stream, amber = API label only.
  The bitrate is snapped to the nearest tier (12/48/96/160/320) when within 10 %.
- **Scrobbling**: after 50 % of the track or 4 min of listening (tracks > 30 s). Enter your own free Last.fm API key/secret in Settings (or bake one in with LASTFM_API_KEY/SECRET). Titles are cleaned ("(From ...)" removed), the primary artist is sent, failed scrobbles are queued and retried, and Settings shows the last Last.fm reply.
- **Size**: arm64-v8a only, English resources only, no Material3/icon libs, vector-only icon, R8 + resource shrinking.

## Sound (equalizer)
`AudioFx` attaches Android's system Equalizer, BassBoost, Virtualizer and LoudnessEnhancer to ExoPlayer's audio
session. Ten presets are curves on five anchor frequencies (`EqPresets`), resampled to the device's own bands and
scaled by an intensity slider. Some phones' vendor sound enhancers can override system effects.

## AI Mix
Bring your own key for any OpenAI-compatible `/chat/completions` endpoint (Settings). The model proposes songs,
each is matched to a playable JioSaavn track, and mixes can be saved on-device. "Quick mix" needs no key.
Recent plays are sent as taste hints only when you switch that on.

## Crash recorder
Uncaught exceptions are saved locally and shown in Settings -> Last crash (Copy). Nothing leaves the phone.

## Known gaps
- First build compiled and ran on a real phone; the direct JioSaavn source (v0.1.1) is untested against the live service.
- Lyrics path `songs/{id}/lyrics` is unverified against sumitkolhe/jiosaavn-api; edit `SaavnRepository.lyrics()` if needed.
- Session key and API key are stored in plain SharedPreferences.

## Notification
The MediaSession carries a session activity (`setSessionActivity`), so tapping the notification or lock-screen card opens Melodyne on the Now Playing screen.
