# Changelog

## v0.11.0
- New skin, Budokan: a well-loved mid-80s black metal pocket cassette player, full screen with the status bar hidden. Brushed gunmetal with grain, an uneven sheen (polished where hands rest), recessed panel lines, a bevel and Phillips screws; paint chipped off the edges and corners with bare aluminium showing through; micro-scratches that are denser where hands grip; gold lettering that is faded, smudged and chipped; a hazy, yellowed, scuffed window with dust trapped in its recessed rim; a cassette that slides in, whose reels turn at the right relative speeds with the tape moving from spool to spool; chunky green keys that sink when pressed (and stay down while active), worn smooth by finger oil; a ridged volume wheel; a warm red light that glows and flickers while playing; an LCD readout with the title, time and bitrate; a printed tape-position scale with a worn gold marker.
- Mint, Used or Well loved (the default), and green or silver keys (collectors say the original had silver), in Settings > Appearance.
- Fixes the build errors in the Cassette skin: a local variable hid the drawing scope's density, and one comparison was read as a type argument by the compiler.

## v0.10.2
- Fixes a build error in the equaliser panel (a missing import).
- Cassette skin, refined against the photo. The song title is no longer covered: the label now has its own writing band above the reel window, with the window and cassette re-proportioned like a real one (the writing used to run into the window, which painted over it).
- Marks of use: scratches (black on the silver grille, bright on the glass), dust, smudges and fingerprints on the smoked glass, a few grille holes clogged with lint, yellowing silver, scuffs at the corners of the case, thumb-polished keys, a faded record lamp, a chipped plate and a cream plastic lever in the door as in the photo, and a creased, stained label. Choose Mint, Used or Well worn in Settings > Appearance (default Used). The marks are fixed, so the same machine looks the same every time.
- The grille now has 38 columns of holes like the original, drawn in batches so the bass pulse stays smooth. The outline arrow is printed on the glass and stays visible with a cassette in. The door leaves a margin around the cassette so the machine's own parts show. PLAY is the wider first key, and a base lip finishes the case.

## v0.10.1
- The player now says which mode is active. A banner slides in from the top when you open Now Playing and whenever the mode changes (including Frugal switching itself on or off in Auto), naming the mode and what it is doing to the sound: Normal lists any active effects, Audiophile says what is bypassed, Frugal says why it is on (switched on, Battery Saver, or mobile data) and the stream quality. It works over every skin, including the full-screen ones.
- A small mode label (NORMAL, AUDIOPHILE, FRUGAL, or FRUGAL · AUTO) stays under the top bar; tap it to show the banner again. The banner can be switched off in Settings > Look & feel > Appearance.

## v0.10.0
- Equaliser rework, after studying how JamesDSP's arbitrary-response equaliser and AutoEQ work. Ten octave bands (31 Hz to 16 kHz) instead of seven; saved custom curves move across automatically.
- The sliders are replaced by a response curve you drag, drawn over the live spectrum. A solver compensates for neighbouring bands overlapping, so the curve you draw is the curve you get (a slider at +6 dB really gives +6 dB at that frequency). Headroom is measured from the filters that actually run.
- Save your own presets by name (and delete them), reset to flat, and import headphone-correction profiles: copy the text of an AutoEQ ParametricEQ or GraphicEQ file, tap Paste profile, and the curve matches it. Peaking and shelving filters are supported.
- The Amp skin's Equalizer window and the receiver skin's bass and treble knobs follow the ten bands; the range is now ±12 dB.

## v0.9.5
- The Cassette skin is redesigned after a black-and-silver pocket cassette recorder, and takes the whole screen with the status bar hidden. A silver speaker grille whose holes breathe with the bass; a smoked-glass door with a real cassette behind it that slides in for every song; reels that turn at physically correct speeds (the small reel faster than the big one) while the tape moves from one spool to the other with the song's progress; a brushed-silver strip; silk-screened labels over piano keys that stay down while active, with a lamp on PLAY.
- Hold REVIEW or CUE to wind (the reels spin fast), tap them to skip, drag along the door to seek, tap EJECT/PAUSE to pause, long-press it to eject (leave the screen). A ribbed volume slide sets the phone's real volume. EQ, Lyrics, Queue and Menu sit on the silver strip.

## v0.9.4
- Settings, reorganised: five groups (Sound, Data & battery, Look & feel, Accounts & sources, App) of collapsible sections, each with a one-line summary of its current state. Playback and Sound quality are split, Car & Bluetooth lives under Sound quality, Frugal mode and Storage are together, the crash log sits inside About (and opens by itself when there is one), and the Appearance, Last.fm, AI and Custom source sections are unchanged inside.
- Removed the private-repository option (the repository and GitHub token fields). Updates always come from the public release, and any token saved by an earlier version is deleted.

## v0.9.3
- The Classic Amp skin now takes the whole screen: the status and navigation bars are hidden while it is showing (swipe from the edge to peek) and come back when you leave, and it draws around a camera notch. The main window sits on top, the Equalizer window opens under it, and the lower window fills the rest of the screen as a scrolling playlist or a big spectrum analyser. EQ, PL, LYR, INF and MENU buttons replace the old top bar; the window's close button leaves the screen.

## v0.9.2
- Clears its cache when the app closes: artwork, buffered audio, Last.fm lookups and finished update downloads are deleted when you swipe Vina away (never while music is playing). Your library, playlists and settings are untouched. If Android ended the app without warning, the next start tidies up when more than 20 MB was left behind.
- Settings > Storage: a switch for this (on by default), the current cache size, and a Clear now button.
- The widget's artwork now lives outside the cache, so clearing never blanks it.

## v0.9.1
- Frugal mode (Off / On / Auto): saves mobile data and battery at the cost of sound quality. Streams drop to 48, 96 or 160 kbps, artwork shrinks, the buffer is smaller, and EQ, normalisation, crossfade, skins, glow and Last.fm lookups switch off. Auto turns on over mobile data or Battery Saver. A FRUGAL chip sits on Home.
- Widget: resizes across a much wider range and has a new tiny layout; remove and re-add it once so the launcher picks up the new sizes.
- Fixes the Cassette skin, which crashed while drawing its VU meter scale.

## v0.9.0
- Melodyne is now Vina. Same app: it installs over your current one, and your playlists, settings and Last.fm login carry across.
- Sleep timer: 5 to 90 minutes or "end of this song", with a 20-second fade-out, +15 minutes, and a countdown on Now Playing. It works with the app closed.
- About page now says what it should.
- Fixes a build error in the skins (a missing import).

## v0.8.0
- Widget upgrade: three layouts that switch as you resize it (compact, standard, large), a progress bar and elapsed time that keep moving while you play, an accent colour taken from the artwork, and a Play button that opens the app when nothing is loaded.
- Classic Amp skin, closer to the 90s originals: titled windows with shade and close, real seven-segment time, a spectrum with falling peak caps, a green-to-red volume bar, an Equalizer window with your seven bands (and the automatic preamp readout), and a playlist window.
- Cassette skin: a tape that slides in, ruled label, screws, spring-damped VU needles with a dB scale, piano keys that stay pressed.
- Receiver skin: walnut side panels, brushed silver, a tuner dial whose needle follows the song, LED meters, and bass and treble knobs that really move your EQ.
- Skin buttons give a small haptic click.

## v0.7.1
- Update notifications: a background check every few hours tells you when a new release exists. Tap the notification and the download starts by itself; when it finishes, tap "Install". Works with Vina closed. Turn it off in Settings > Updates.
- Now Playing home-screen widget: artwork, title, artist, live quality label, and working previous, play/pause and next buttons. Tap the art or title to open the player. Add it from Settings or the Widgets menu.

## v0.7.0
- Welcome tour: shown once on every install (including updates), explains Audiophile Mode, the sound tools and what is different here; replay it from Settings > Appearance.
- Fidelity: dithered 16-bit output, stereo width and a Car & Bluetooth curve and profile, gentle (reduce-only) normalisation, a dynamics readout (PLR) in the signal chain, and Bluetooth/car guidance.
- Skins that do real work: Classic Amp, Cassette and Receiver, with a live 16-band spectrum, VU needles from the real levels, lamps that reflect the real state, working volume, balance, knob, tuning dial and hold-to-scrub.
- Artist pages with Songs, Albums, Similar and About; every credited artist on Now Playing is tappable.
- Top 10 in 18 languages, refreshed through the day (3-hour cache), with arrows for what moved.
- Queue view on Now Playing.

## v0.6.1
- Now Playing has a ••• menu: Go to album (full track list), Go to composer (credits, Last.fm bio and genres, songs), Add to playlist, Signal chain.
- Now Playing layout: the title, artist and genre tags sit right under the artwork, and the bitrate pill sits just above the progress bar.
- Songs now carry their album id and composer; saved playlists from earlier versions still load.

## v0.6.0
- Liquid glass look: translucent panels with a light-catching edge, a floating glass navigation bar with a springy "liquid" indicator, glass sheets and dialogs, soft colour glow behind everything and a blurred-artwork backdrop on Now Playing (Settings > Appearance turns the glow off for pure AMOLED black).
- Exact live bitrate: every compressed audio frame is measured as it plays, so the number is real and moves with variable-bitrate files; average = file size / duration; tap the badge for a 40-second line chart.
- Infinite play: when the queue is nearly done, similar songs (Last.fm similar tracks and artists) are queued automatically. Toggle with the infinity chip on Now Playing.
- Genre cloud (Search tab) sized by Last.fm's tag chart, with Indian genres added; every word opens a genre page. Genre tags on Now Playing are tappable.
- Crossfade engine (1-12 s, equal-power or linear), locked in Audiophile Mode; Normal / Audiophile / Party profiles; gapless pauses while crossfading.
- Catalogue playlists removed entirely; your own playlists, smart playlists and AI mixes are unchanged.

## v0.5.0
- Update notifier: Home shows a banner when a newer GitHub release exists; Settings > Updates can check on demand.
- Audiophile Mode (switch on Home): bypasses EQ, normalisation and crossfade, shows an honest signal chain (source, decode, processing, OS path, output), and asks Android 14+ for the bit-perfect USB path when a USB DAC is connected.
- Audio Tuning in Settings: loudness normalisation (BS.1770 measurement, -14 LUFS target, remembered per song), gapless status, crossfade placeholder, Bluetooth absolute-volume shortcut.
- Last.fm enrichment (24 h cache): song tags and listener counts on Now Playing, "Because you listened to ...", "On repeat", and a Trending chart for India.
- Moods now come from Last.fm tags instead of words in titles.
- Now Playing: no more artwork flicker, swipe left/right for next/previous, swipe up for synced lyrics (LRCLIB first).
- AI settings: key links for OpenRouter, Groq and OpenAI, plus Test connection.
- Hidden screen: search 1509, or tap the version in Settings five times.
- Every version is now its own commit and release on GitHub.

## v0.4.0
- 7-band software EQ with automatic headroom, reachable from Now Playing; flat or off is bit-for-bit untouched.
- Library: custom playlists, smart playlists, import/export, add to playlist from any song.
- Search results de-duplicated; Now Playing redesigned; all source references removed from the app.

## v0.3.0
- New Home, Last.fm scrobbling fixed (own API key in Settings), notification tap opens the app.

## v0.2.0
- Playback crash fixed, crash recorder, AI Mix, redesigned Settings.
